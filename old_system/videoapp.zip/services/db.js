const Database = require('better-sqlite3');
const path = require('path');
const { dbPath, adminToken } = require('../config');

let db;

function getDb() {
    if (!db) {
        db = new Database(dbPath);
        db.pragma('journal_mode = WAL');
        db.pragma('foreign_keys = ON');
    }
    return db;
}

function initDB() {
    const d = getDb();

    d.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      auth_id TEXT UNIQUE NOT NULL,
      label TEXT NOT NULL,
      is_admin INTEGER NOT NULL DEFAULT 0,
      quota_bytes INTEGER NOT NULL DEFAULT 10737418240,
      default_expiry_days INTEGER,
      created_at INTEGER NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id),
      created_at INTEGER NOT NULL,
      expires_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS files (
      id TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id),
      original_name TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      size_bytes INTEGER NOT NULL,
      storage_path TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      expires_at INTEGER,
      is_private INTEGER NOT NULL DEFAULT 0,
      show_uploader INTEGER NOT NULL DEFAULT 1
    );
  `);

    const col = d.prepare("SELECT name FROM pragma_table_info('files') WHERE name='is_private'").get();
    if (!col) {
        d.prepare('ALTER TABLE files ADD COLUMN is_private INTEGER NOT NULL DEFAULT 0').run();
    }

    const showUploaderCol = d.prepare("SELECT name FROM pragma_table_info('files') WHERE name='show_uploader'").get();
    if (!showUploaderCol) {
        d.prepare('ALTER TABLE files ADD COLUMN show_uploader INTEGER NOT NULL DEFAULT 1').run();
    }

    const existing = d.prepare('SELECT id FROM users WHERE auth_id = ?').get(adminToken);
    if (!existing) {
        d.prepare(
            'INSERT INTO users (auth_id, label, is_admin, quota_bytes, default_expiry_days, created_at, is_active) VALUES (?, ?, 1, ?, NULL, ?, 1)'
        ).run(adminToken, 'Admin', 10737418240, Date.now());
    }
}

function getUserByAuthId(authId) {
    return getDb().prepare('SELECT * FROM users WHERE auth_id = ?').get(authId);
}

function getUserById(id) {
    return getDb().prepare('SELECT id, label, is_admin FROM users WHERE id = ?').get(id);
}

function createSession(sessionId, userId, expiresAt) {
    getDb()
        .prepare('INSERT INTO sessions (id, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)')
        .run(sessionId, userId, Date.now(), expiresAt);
}

function getSessionWithUser(sessionId) {
    return getDb()
        .prepare(
            `SELECT s.id AS session_id, s.expires_at, u.*
       FROM sessions s
       JOIN users u ON u.id = s.user_id
       WHERE s.id = ?`
        )
        .get(sessionId);
}

function deleteSession(sessionId) {
    getDb().prepare('DELETE FROM sessions WHERE id = ?').run(sessionId);
}

function createFile({ id, userId, originalName, mimeType, sizeBytes, storagePath, createdAt, expiresAt, isPrivate }) {
    getDb()
        .prepare(
            'INSERT INTO files (id, user_id, original_name, mime_type, size_bytes, storage_path, created_at, expires_at, is_private) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
        )
        .run(id, userId, originalName, mimeType, sizeBytes, storagePath, createdAt, expiresAt ?? null, isPrivate ? 1 : 0);
}

function getFileById(fileId) {
    return getDb().prepare('SELECT * FROM files WHERE id = ?').get(fileId);
}

function getUserFiles(userId, search) {
    if (search) {
        return getDb()
            .prepare('SELECT * FROM files WHERE user_id = ? AND original_name LIKE ? ORDER BY created_at DESC')
            .all(userId, `%${search}%`);
    }
    return getDb()
        .prepare('SELECT * FROM files WHERE user_id = ? ORDER BY created_at DESC')
        .all(userId);
}

function getAllFiles(search) {
    if (search) {
        return getDb()
            .prepare(
                `SELECT f.*, u.label AS user_label
         FROM files f JOIN users u ON u.id = f.user_id
         WHERE f.original_name LIKE ?
         ORDER BY f.created_at DESC`
            )
            .all(`%${search}%`);
    }
    return getDb()
        .prepare(
            `SELECT f.*, u.label AS user_label
       FROM files f JOIN users u ON u.id = f.user_id
       ORDER BY f.created_at DESC`
        )
        .all();
}

function deleteFile(fileId) {
    getDb().prepare('DELETE FROM files WHERE id = ?').run(fileId);
}

function getAllUsers() {
    return getDb().prepare(`
        SELECT u.*,
               COALESCE((SELECT SUM(f.size_bytes) FROM files f WHERE f.user_id = u.id), 0) AS used_bytes,
               COALESCE((SELECT COUNT(*) FROM files f WHERE f.user_id = u.id), 0) AS file_count
        FROM users u
        ORDER BY u.created_at DESC
    `).all();
}

function createUser(authId, label, isAdmin, quotaBytes, defaultExpiryDays) {
    getDb()
        .prepare(
            'INSERT INTO users (auth_id, label, is_admin, quota_bytes, default_expiry_days, created_at, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)'
        )
        .run(authId, label, isAdmin ? 1 : 0, quotaBytes, defaultExpiryDays ?? null, Date.now());
}

function updateUser(userId, data) {
    const allowed = ['label', 'is_admin', 'quota_bytes', 'default_expiry_days', 'is_active'];
    const keys = Object.keys(data).filter(k => allowed.includes(k));
    if (keys.length === 0) return;
    const sets = keys.map(k => `${k} = ?`).join(', ');
    const values = keys.map(k => data[k]);
    getDb().prepare(`UPDATE users SET ${sets} WHERE id = ?`).run(...values, userId);
}

function deactivateUser(userId) {
    getDb().prepare('UPDATE users SET is_active = 0 WHERE id = ?').run(userId);
}

function deleteUserById(userId) {
    const files = getDb().prepare('SELECT * FROM files WHERE user_id = ?').all(userId);
    getDb().prepare('DELETE FROM files WHERE user_id = ?').run(userId);
    getDb().prepare('DELETE FROM sessions WHERE user_id = ?').run(userId);
    getDb().prepare('DELETE FROM users WHERE id = ?').run(userId);
    return files;
}

function getUserUsage(userId) {
    const row = getDb()
        .prepare('SELECT COALESCE(SUM(size_bytes), 0) AS total FROM files WHERE user_id = ?')
        .get(userId);
    return row.total;
}

function getExpiredFiles() {
    return getDb()
        .prepare('SELECT * FROM files WHERE expires_at IS NOT NULL AND expires_at < ?')
        .all(Date.now());
}

function cleanExpiredSessions() {
    getDb().prepare('DELETE FROM sessions WHERE expires_at < ?').run(Date.now());
}

function updateFile({ id, originalName, expiresAt, isPrivate, showUploader }) {
    const sets = [];
    const vals = [];
    if (originalName !== undefined) { sets.push('original_name = ?'); vals.push(originalName); }
    if (expiresAt !== undefined) { sets.push('expires_at = ?'); vals.push(expiresAt ?? null); }
    if (isPrivate !== undefined) { sets.push('is_private = ?'); vals.push(isPrivate ? 1 : 0); }
    if (showUploader !== undefined) { sets.push('show_uploader = ?'); vals.push(showUploader ? 1 : 0); }
    if (sets.length === 0) return;
    getDb().prepare(`UPDATE files SET ${sets.join(', ')} WHERE id = ?`).run(...vals, id);
}

function getAdminStats() {
    const d = getDb();
    const totalUsers = d.prepare('SELECT COUNT(*) AS cnt FROM users WHERE is_active = 1').get().cnt;
    const totalFiles = d.prepare('SELECT COUNT(*) AS cnt FROM files').get().cnt;
    const totalStorage = d.prepare('SELECT COALESCE(SUM(size_bytes), 0) AS total FROM files').get().total;
    return { totalUsers, totalFiles, totalStorage };
}

module.exports = {
    initDB,
    getUserByAuthId,
    getUserById,
    createSession,
    getSessionWithUser,
    deleteSession,
    createFile,
    getFileById,
    getUserFiles,
    getAllFiles,
    deleteFile,
    getAllUsers,
    createUser,
    updateUser,
    deactivateUser,
    deleteUserById,
    getUserUsage,
    getExpiredFiles,
    cleanExpiredSessions,
    updateFile,
    getAdminStats,
};
