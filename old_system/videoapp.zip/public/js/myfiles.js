function copyText(text, onSuccess) {
    text = text.replace(/([^:])\/\/+/g, '$1/');
    function execFallback() {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.cssText = 'position:fixed;top:-999px;left:-999px;opacity:0;';
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        try { document.execCommand('copy'); onSuccess(); } catch (_) { }
        document.body.removeChild(ta);
    }
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(onSuccess).catch(execFallback);
    } else {
        execFallback();
    }
}

function fmtBytes(b) {
    if (b >= 1073741824) return (b / 1073741824).toFixed(2) + ' GB';
    if (b >= 1048576) return (b / 1048576).toFixed(1) + ' MB';
    if (b >= 1024) return (b / 1024).toFixed(0) + ' KB';
    return b + ' B';
}

function fmtDate(ts) {
    if (!ts) return '—';
    const d = new Date(ts);
    const date = d.toLocaleDateString('ja-JP');
    const time = d.toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit' });
    return `${date} ${time}`;
}

function esc(s) {
    return String(s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;')
        .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

async function loadStats() {
    const stats = await fetch('/api/user/stats').then(r => r.json());
    const pct = stats.quotaBytes > 0 ? Math.min(100, stats.usedBytes / stats.quotaBytes * 100) : 0;
    document.getElementById('usage-bar').style.width = pct + '%';
    document.getElementById('usage-label').textContent =
        `${fmtBytes(stats.usedBytes)} / ${fmtBytes(stats.quotaBytes)}`;
}

async function loadFiles(search = '') {
    const url = '/api/user/files' + (search ? `?search=${encodeURIComponent(search)}` : '');
    const files = await fetch(url).then(r => r.json());
    const tbody = document.getElementById('file-list');
    if (files.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-sub">\u30d5\u30a1\u30a4\u30eb\u304c\u3042\u308a\u307e\u305b\u3093</td></tr>';
        updateBulkBtn();
        return;
    }
    tbody.innerHTML = files.map(f => `
    <tr>
      <td style="width:1%;padding:.5rem 1rem">
        <label class="custom-cb">
          <input type="checkbox" class="file-check" data-id="${esc(f.id)}">
          <span class="custom-cb-box"></span>
        </label>
      </td>
      <td><a href="/f/${esc(f.id)}" target="_blank" style="color:var(--accent3);text-decoration:none">${esc(f.original_name)}</a>${f.is_private ? '<span class="badge badge-gray" style="margin-left:.4rem;font-size:.65rem">非公開</span>' : ''}</td>
      <td>${fmtBytes(f.size_bytes)}</td>
      <td class="col-date">${fmtDate(f.created_at)}</td>
      <td class="col-date">${fmtDate(f.expires_at)}</td>
      <td style="width:1%;white-space:nowrap">
        <div style="display:flex;gap:.4rem;flex-wrap:nowrap;align-items:center;white-space:nowrap">
          <a class="btn btn-ghost btn-sm" href="/f/${esc(f.id)}/download" style="padding:.22rem .55rem;font-size:.74rem" title="ダウンロード"><svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> DL</a>
          <button class="btn btn-ghost btn-sm copy-discord-btn" data-id="${esc(f.id)}/raw" style="padding:.22rem .55rem;font-size:.74rem;color:#8b5cf6;border-color:rgba(139,92,246,.3)" title="Discord用"><svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg> Discord</button>
          <button class="btn btn-danger btn-sm delete-btn" data-id="${esc(f.id)}" style="padding:.22rem .55rem;font-size:.74rem">削除</button>
        </div>
      </td>
    </tr>
  `).join('');

    document.querySelectorAll('.file-check').forEach(cb => {
        cb.addEventListener('change', updateBulkBtn);
    });

    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
            if (!confirm('\u3053\u306e\u30d5\u30a1\u30a4\u30eb\u3092\u524a\u9664\u3057\u307e\u3059\u304b\uff1f')) return;
            const res = await fetch(`/api/user/files/${btn.dataset.id}`, { method: 'DELETE' });
            if (res.ok) {
                loadStats();
                loadFiles(document.getElementById('search-input').value.trim());
            } else {
                alert('\u524a\u9664\u306b\u5931\u6557\u3057\u307e\u3057\u305f');
            }
        });
    });

    document.querySelectorAll('.copy-discord-btn').forEach(btn => {
        const origHTML = btn.innerHTML;
        btn.addEventListener('click', () => {
            const url = `${location.origin}/f/${btn.dataset.id}`;
            const w = btn.offsetWidth;
            btn.style.minWidth = w + 'px';
            copyText(url, () => {
                btn.textContent = '✓ コピー済み';
                setTimeout(() => { btn.innerHTML = origHTML; btn.style.minWidth = ''; }, 2000);
            });
        });
    });

    document.getElementById('select-all').checked = false;
    updateBulkBtn();
}

async function init() {
    const me = await fetch('/api/auth/me').then(r => r.json());
    document.getElementById('nav-username').textContent = me.label;
    if (me.isAdmin) document.getElementById('nav-admin-link').classList.remove('hidden');

    loadStats();
    loadFiles();

    document.getElementById('search-btn').addEventListener('click', () => {
        loadFiles(document.getElementById('search-input').value.trim());
    });

    document.getElementById('search-input').addEventListener('keydown', e => {
        if (e.key === 'Enter') loadFiles(document.getElementById('search-input').value.trim());
    });

    document.getElementById('select-all').addEventListener('change', function () {
        document.querySelectorAll('.file-check').forEach(cb => { cb.checked = this.checked; });
        updateBulkBtn();
    });

    document.getElementById('bulk-delete-btn').addEventListener('click', async () => {
        const ids = Array.from(document.querySelectorAll('.file-check:checked')).map(cb => cb.dataset.id);
        if (ids.length === 0) return;
        if (!confirm(`${ids.length} 件のファイルを削除しますか？`)) return;
        await Promise.all(ids.map(id => fetch(`/api/user/files/${id}`, { method: 'DELETE' })));
        loadStats();
        loadFiles(document.getElementById('search-input').value.trim());
    });

    document.getElementById('logout-btn').addEventListener('click', async () => {
        await fetch('/api/auth/logout', { method: 'POST' });
        location.href = '/login';
    });
}

function updateBulkBtn() {
    const count = document.querySelectorAll('.file-check:checked').length;
    const btn = document.getElementById('bulk-delete-btn');
    btn.style.display = count > 0 ? '' : 'none';
    btn.textContent = count > 0 ? `選択分を削除 (${count})` : '選択分を削除';
}

init();
